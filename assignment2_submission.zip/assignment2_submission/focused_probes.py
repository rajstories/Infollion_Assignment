from oracle import quote

print('DISTANCE')
for d in [1,2,10,20,40,49,50,51,75,99,100,101,149,150,151,199,200,201,249,250,251,299,300,301,399,400,401,499,500,501,749,750,999,1000,1001,1499,1500,1501,1999,2000,2001,3000,4000,5000]:
    print(d, quote(2,d,'standard'))
print('WEIGHT')
for w in [0.1,0.49,0.5,0.51,0.99,1,1.01,1.49,1.5,1.51,1.99,2,2.01,2.49,2.5,2.51,2.99,3,3.01,4,4.99,5,5.01,7.5,9.99,10,10.01,19.99,20,20.01,50,99.99,100]:
    print(w, quote(w,100,'standard'))
print('CATEGORIES')
for cat in ['standard','electronics','fragile','books','clothing','food']:
  for w,d in [(0.5,1),(1,100),(2,100),(5,100),(2,200),(2,1000)]:
    print(cat,w,d,quote(w,d,cat))
print('EXPRESS')
for cat in ['standard','electronics','fragile','books','clothing','food']:
  for w,d in [(0.5,1),(2,100),(5,100),(2,1000)]:
    a=quote(w,d,cat,False); b=quote(w,d,cat,True)
    print(cat,w,d,a,b,b-a)
print('COUPONS')
for c in ['WELCOME10','WELCOME10 ',' WELCOME10','WELCOME10\n','WELCOME5','WELCOME15','WELCOME25','WELCOME50','WELCOME100','WELCOME010','welcome10','WELCOME-10']:
  print(repr(c),quote(2,100,'standard',False,c),quote(10,1000,'standard',False,c))
