from oracle import quote
for d in range(245, 306):
    regular = quote(2,d,'standard')
    raw = 80 + 2.5*d
    print(d, regular, regular-raw)
