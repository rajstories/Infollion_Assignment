"""Reimplementation of the shipping quote engine inferred experimentally."""

import math


def quote(weight_kg, distance_km, category, express=False, coupon=""):
    """Return the inferred shipping price, rounded to two decimal places."""
    # Weight is billed in half-kilogram bands, with a 20-unit charge per band.
    weight_charge = math.ceil(weight_kg * 2) * 20
    price = weight_charge + (distance_km * 2.5)

    # Category-specific adjustments.
    if category == "electronics":
        price *= 1.30
    elif category == "fragile":
        price += 150

    # The express flag has no observable effect in the valid input domain.
    # A 10% discount applies when the adjusted subtotal is strictly above 800.
    if price > 800:
        price *= 0.90

    # WELCOME10 is a fixed 100-unit reduction, applied after the percentage
    # discount. Other coupon strings have no observable effect.
    if coupon == "WELCOME10":
        price -= 100

    return round(price, 2)


def queries_used():
    """Compatibility placeholder; this independent implementation makes no oracle calls."""
    return 0


def reset_counter():
    """Compatibility placeholder for the oracle API."""
    return None
