# Investigation Summary

- I established a baseline by querying every listed category with the same weight and distance.
- I varied distance while holding weight and category constant and found a linear distance charge of `2.5 × distance_km`.
- I varied weight around half-kilogram boundaries and found that weight is rounded up to 0.5 kg bands, with a charge of 20 units per band.
- I initially suspected that weight rates changed at higher weights because the final output appeared to jump irregularly; this was incorrect. The apparent change was caused by the 10% subtotal discount activating above 800 units.
- I compared all categories and found that `electronics` multiplies the subtotal by 1.30, `fragile` adds 150 units, and `standard`, `books`, `clothing`, and `food` showed no category adjustment.
- I tested distances around the apparent transition and discovered that the discount is based on the adjusted subtotal being strictly greater than 800, rather than on a fixed distance threshold.
- I tested `express=True` and `express=False` across categories, weights, and distances; no observable difference was found.
- I tested coupon spelling, case, whitespace, and several coupon names. Only the exact case-sensitive code `WELCOME10` subtracts 100 units.
- I tested combinations and boundary values to determine operation order: category adjustment, then the >800 discount, then the fixed coupon subtraction, followed by final rounding.
