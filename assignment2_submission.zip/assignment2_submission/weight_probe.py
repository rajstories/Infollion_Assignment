from oracle import quote
for i in range(1,201):
    w=i/2
    print(w, quote(w,100,'standard')-250)
