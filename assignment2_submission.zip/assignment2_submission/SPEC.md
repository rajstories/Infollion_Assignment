# Shipping Quote Pricing Specification

This specification describes the behavior inferred by querying `oracle.quote()` with valid inputs.

## 1. Base charge

The base charge is the sum of a weight charge and a distance charge:

```text
base = weight_charge + distance_charge
```

The distance charge is linear:

```text
distance_charge = 2.5 × distance_km
```

For example, with `weight_kg=2.0` and `distance_km=100.0`, the distance charge is `250.0`.

The weight is billed in 0.5 kg bands. Each band costs 20 units, and any fraction of a band is rounded up:

```text
weight_charge = ceil(weight_kg × 2) × 20
```

Examples:

| Query | Weight charge | Observed subtotal before other rules |
|---|---:|---:|
| `weight_kg=0.5, distance_km=100` | 20 | 270 |
| `weight_kg=0.51, distance_km=100` | 40 | 290 |
| `weight_kg=2.0, distance_km=100` | 80 | 330 |
| `weight_kg=10.0, distance_km=100` | 400 | 650 |

## 2. Category adjustments

The category adjustment is applied to the base charge as follows:

| Category | Rule |
|---|---|
| `standard` | No adjustment |
| `books` | No adjustment observed |
| `clothing` | No adjustment observed |
| `food` | No adjustment observed |
| `electronics` | Multiply the base charge by `1.30` |
| `fragile` | Add a fixed surcharge of `150` units |

Examples:

- `quote(2.0, 100.0, "standard")` returns `330.00`.
- `quote(2.0, 100.0, "electronics")` returns `429.00`, because `330 × 1.30 = 429`.
- `quote(2.0, 100.0, "fragile")` returns `480.00`, because `330 + 150 = 480`.
- `quote(2.0, 100.0, "books")` returns `330.00`, the same as `standard`.

## 3. Large-subtotal discount

After the category adjustment, a 10% discount is applied when the subtotal is strictly greater than `800` units:

```text
if adjusted_subtotal > 800:
    adjusted_subtotal *= 0.90
```

The threshold is strict: a subtotal of exactly `800` is not discounted.

Example: `quote(2.0, 289.0, "standard")` returns `722.25`. The subtotal is `80 + (2.5 × 289) = 802.5`, and `802.5 × 0.90 = 722.25`.

## 4. Coupon

Only the exact, case-sensitive string `WELCOME10` has an observed effect. It subtracts a fixed `100` units after the large-subtotal discount:

```text
if coupon == "WELCOME10":
    price -= 100
```

Other strings, including `welcome10`, `WELCOME5`, and strings with extra whitespace, have no observed effect.

Example: `quote(2.0, 100.0, "standard", coupon="WELCOME10")` returns `230.00`, because `330 - 100 = 230`.

The coupon is not clamped at zero. For example, `quote(0.5, 1.0, "standard", coupon="WELCOME10")` returns `-77.50`.

## 5. Express flag

The `express` argument has no observable effect for the tested valid inputs. Both `express=False` and `express=True` return the same price. The reimplementation accepts the argument for API compatibility but does not use it.

## 6. Rounding

The final result is rounded to two decimal places using Python's normal `round(value, 2)` behavior.

## 7. Complete inferred formula

For valid inputs, the implementation is equivalent to:

```python
price = ceil(weight_kg * 2) * 20 + distance_km * 2.5

if category == "electronics":
    price *= 1.30
elif category == "fragile":
    price += 150

if price > 800:
    price *= 0.90

if coupon == "WELCOME10":
    price -= 100

return round(price, 2)
```
