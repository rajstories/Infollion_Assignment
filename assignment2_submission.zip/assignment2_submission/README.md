# Assignment 2 Submission

Required deliverables:

- `my_quote.py` — independent reimplementation of `quote()`.
- `SPEC.md` — complete inferred pricing rules and examples.
- `INVESTIGATION_SUMMARY.md` — investigation process and rejected hypotheses.
- `probes.py`, `focused_probes.py`, `final_probes.py`, `threshold_probe.py`, `weight_probe.py` — probe scripts used during investigation.
- `validate.py` — differential validator used to compare the reimplementation with the supplied oracle.

The supplied `oracle.py` is intentionally not included in this clean package because the assignment asks for an implementation that does not import or call it. Run `validate.py` in a directory containing both this package and the supplied `oracle.py` to reproduce the validation.
