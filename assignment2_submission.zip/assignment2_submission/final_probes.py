from oracle import quote

print('FRAGILE DISTANCE')
for w in [0.5,1,2,5,10,20]:
  print('w',w,[(d,quote(w,d,'fragile'),quote(w,d,'standard'),quote(w,d,'fragile')-quote(w,d,'standard')) for d in [1,100,200,250,251,300,400,500,501,750,1000,2000,5000]])
print('COMBINATIONS')
for cat in ['standard','electronics','fragile']:
  for c in ['', 'WELCOME10']:
    for w,d in [(0.5,1),(2,100),(2,1000),(20,5000)]:
      print(cat,repr(c),w,d,quote(w,d,cat,False,c))
print('ROUNDING')
for w in [10,10.0001,10.4999,10.5,10.5001,19.9999,20,20.0001,20.4999,20.5,20.5001]:
 print(w,quote(w,100,'standard'))
