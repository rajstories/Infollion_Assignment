from oracle import quote, queries_used, reset_counter


def show(label, *args, **kwargs):
    print(f"{label:35} -> {quote(*args, **kwargs)!r}")

reset_counter()
print("BASELINES")
for cat in ["standard", "electronics", "fragile", "books", "clothing", "food"]:
    show(cat, 2.0, 100.0, cat)
print("\nWEIGHT / DISTANCE STANDARD")
for w in [0.1, 0.5, 1, 2, 3, 5, 10, 25, 100]: show(f"w={w}", w, 100, "standard")
for d in [1, 10, 50, 100, 101, 200, 500, 1000, 5000]: show(f"d={d}", 2, d, "standard")
print("\nGRID STANDARD")
for w,d in [(1,1),(1,10),(1,100),(2,100),(5,100),(10,100),(2,200),(2,500),(2,1000),(10,1000)]: show(f"w={w},d={d}",w,d,"standard")
print("\nEXPRESS")
for cat in ["standard", "electronics", "fragile", "books", "clothing", "food"]:
    show(cat+" regular", 2,100,cat,False)
    show(cat+" express", 2,100,cat,True)
print("\nCOUPONS")
for c in ["", "WELCOME10", "WELCOME20", "SAVE10", "FREESHIP", "VIP", "welcome10", "INVALID"]:
    show(c or "empty", 2,100,"standard",False,c)
print("\nCALLS", queries_used())
