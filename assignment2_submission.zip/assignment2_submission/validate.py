import random
from oracle import quote as oracle_quote
from my_quote import quote as my_quote

random.seed(20260918)
categories = ["standard", "electronics", "fragile", "books", "clothing", "food"]
coupons = ["", "WELCOME10", "INVALID", "welcome10"]

cases = []
for _ in range(2000):
    cases.append((
        random.uniform(0.1, 100.0),
        random.uniform(1.0, 5000.0),
        random.choice(categories),
        random.choice([False, True]),
        random.choice(coupons),
    ))

# Add important boundaries explicitly.
for w in [0.1, 0.5, 0.500001, 10, 10.000001, 13.5, 13.500001, 100]:
    for d in [1, 100, 288, 288.01, 5000]:
        for cat in categories:
            for coupon in ["", "WELCOME10"]:
                cases.append((w, d, cat, False, coupon))

for i, case in enumerate(cases, 1):
    expected = oracle_quote(*case)
    actual = my_quote(*case)
    if expected != actual:
        raise AssertionError(f"Mismatch at case {i}: {case}: oracle={expected}, mine={actual}")

print(f"PASS: {len(cases)} differential cases matched exactly.")
